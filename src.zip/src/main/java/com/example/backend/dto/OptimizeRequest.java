// OptimizeRequest.java
package com.example.backend.dto;

import lombok.Data;

@Data
public class OptimizeRequest {
    private String sql;
}
